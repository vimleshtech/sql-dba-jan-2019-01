
/**
-having 	  : is conditional stateement which can be apply to filter the summarize data 
				after group by
		      : having can be use only with group by 	
-constraints  : is charracteritics(rules and regulation) of column/attribute 
			  - primary key
						- not null
						- no duplicate
						- physically sorted
			  - not null
						- mandatory field 
			  - null
						- allow now or optional field
			  - unique 
						- no duplicate
						- single null						
			  - in 
						- allow from given list 
			  - default 
						- set/store value automatically in table if user will not submit data
			  - foriegn key 
						- is reference from one table (primary column) to another table
						- foriegn key allow null value, and value which present in primary table			
-wild card
-function 
-subquery
-index

*/

use hrms 

select * from employee

select status_id, count(*) 
from employee group by status_id
--having : show the status if count is greater than 2  
select status_id , count(*) 
from employee 
group by status_id
having  count(*)>2

/*
6. select 
1. from 
2. where
3. group by
4. having
5. order by
*/

-- constraints 
--drop table customer

create table customer
(
cid int primary key,
fname varchar(30) not null,
lname varchar(30) null,
email  varchar(40) unique,
gender  char(1)  check (gender in ('M','F')),
country  varchar(100)  check (country in ('India','US','AUS')),
status_id	int default 1,
create_date  datetime default getdate()
)

insert into customer(cid,fname)
values(10,'jatin')



insert into customer(cid,fname,email)
values(1,'jatin','jk@gmail.com')


insert into customer(cid,fname,email,gender,country)
values(5,'jatin','jk1@gmail.com','M','India')

insert into customer(cid,fname,email,gender,country)
values(3,'rahul','jk01@gmail.com','m','usa')

insert into customer(cid,fname,email,gender,country)
values(12,'sharma','jk02@gmail.com','M','India')

insert into customer(cid,fname,email,gender,country)
values(14,'riya','jk04@gmail.com','f','india')
select * from customer 

--foreign key
--drop table sales_order 

create table sales_order
(
oid int identity(1,1) primary key,
cid  int foreign key references customer(cid),
product  varchar(100),
qty  int,
price int,
odate  datetime default getdate()
)

insert into sales_order (cid,product,qty,price)
values(10,'dove',10,45)


insert into sales_order (cid,product,qty,price)
values(5,'shampoo',100,450)

insert into sales_order (cid,product,qty,price)
values(10,'cake',4,300)

select * from customer
select * from sales_order


select c.cid,c.fname, c.country, s.product,s.qty,s.odate 
from customer as c inner join  sales_order as s
on c.cid =s.cid

select * from customer as c inner join sales_order as s on c.cid=s.cid





