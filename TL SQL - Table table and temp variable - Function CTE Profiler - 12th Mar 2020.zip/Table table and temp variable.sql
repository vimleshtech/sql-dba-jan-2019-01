/*
view
trigger 


temp table & temp variable
temp table : there are following types
	i. # table (session level access)
	ii. ## table (global / cross session access)

temp variable: is also known as table variable
procedure : is precompiled code which can be execute on demand 

*/

--	i. # table (session level access)

create table  #emp
(
eid int,
name varchar(100)
)

insert into #emp 
values(1,'nitin')

insert into #emp 
values(2,'jatin')

	select * from #emp 



--ii. ## table (global / cross session access)

create table  ##emp
(
eid int,
name varchar(100)
)


insert into ##emp 
values(1,'nitin')

insert into ##emp 
values(2,'jatin')



-- temp variable: is also known as table variable
declare @test as table
(id int,
name varchar(100)
)

insert into @test
values(1,'nitin')

select * from @test

declare @emp as table
(id int identity(1,1),
f_name varchar(100),
salary int)
insert into @emp values('thomas',50000)

insert into @emp values('john',33000)

insert into @emp values('joy',40000)
select * from @emp


use hrms

select * from test 

-- create proc
create proc p_save_data
(
--@id int,
@name varchar(100),
@email varchar(400)
)
as
begin

	insert into test 
	values(@name,@email)		

end 
p_save_data  'jyoti','jyoti@gmail.com'

alter proc pr_dtsave
(
@eid int,
@name varchar(100),
@salary int)
as begin
	
	insert into proc_test
	values (@eid,@name,@salary)
end

create table proc_test
(
eid int,
name varchar(100),
salary int
)


pr_dtsave 11,'fff',556666
select * from proc_test
