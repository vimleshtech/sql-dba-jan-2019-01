/*
TL-SQL
----------
variable declaration
set
loop
condition 

view
trigger
procedure 

---------------
function 
profiler 
cte			
cursor 


*/
-- function : is pre-compiled sql statement which can be reused
-- function must have return type
-- function may or may not take argument 
-- there are following types of user defined function 
-- i. scaller function (which return single value)
-- ii. tabular function (which can return multi rows or a table)
-- iii. aggregiate function (which works single column and return single value)

/*
function vs procedure
i. procedure may or may not return value
	function must return value 
ii. we can write any type of sql statement in procedure
  however we can write only select,tl-sql statement in function 
     (wen can not delete, update , insert data in physical table in a function )
iii. 
	function can use as table 
	howevere procedure cannot be 
*/
use hrms 


select dbo.sum_num(111,445)
select 111+445
select sum(111,445)

select *  from Student_Name

select sum(roll_code)  from Student_Name

select *, dbo.incometax(basic*12) from salary 

/*
profiler : is monitering tool to view perfomance of database and its' object
		: we can also store the log 
*/


select * from salary



delete from salary where eid =2

update salary 
set basic =44566
where eid =4


use my_learning

select * from mylog

/*
cte : common type expression 
syntax:
with name 
(
		select * from ...
			..
)



*/
/* delete duplicate using cte */



 CREATE TABLE dbo.Employee2
	( 
	EmpID int IDENTITY(1,1) NOT NULL, 
	Name varchar(55) NULL, 
	Salary decimal(10, 2) NULL, 
	Designation varchar(20) NULL
	 )

insert into Employee2
values('nitin',55677,'manager')

insert into Employee2
values('nitin',355677,'manager')


insert into Employee2
values('rahul',1255677,'se')

insert into Employee2
values('monika',677888,'dev')




select * from Employee2


WITH x (name,salary,rn)
AS
(
	SELECT name,salary,
	ROW_NUMBER() OVER(PARTITION by Name, Salary,Designation ORDER BY Name,salary,Designation) 
	AS rn
	FROM dbo.Employee2 
)
--select * from x 
delete from x where rn>1 ;


use hrms 

WITH a (eid,name,basic,da )
AS
(
	SELECT top 2 eid,hra, basic, da  
	FROM salary order by basic desc 
)
select  top 1 * from a  order by basic  asc 


--- function 
CREATE FUNCTION incometax
(
 @sal int


)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @n as int

	IF @sal <250000
	begin 
			set @n  = 0

	end
	else if @sal< 500000
	begin 
		set @n  =  (@sal-250000)*.05

	end 
	else if @sal< 1000000
	begin 
		set @n  =  12500 + (@sal-500000)*.20

	end 
	else
	begin
			set @n  =  112500 + (@sal-1000000)*.30

	end


	-- Return the result of the function
	RETURN @n 

END
GO


---

CREATE FUNCTION sum_num
(
 @n1 int
,@n2 int

)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @n as int

	-- Add the T-SQL statements to compute the return value here
	set @n = @n1 + @n2 

	-- Return the result of the function
	RETURN @n 

END
GO


	
