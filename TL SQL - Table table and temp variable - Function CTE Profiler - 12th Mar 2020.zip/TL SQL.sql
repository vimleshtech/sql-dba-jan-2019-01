
/*
TL SQL - transactional sql 

- declare variable 
*/

--delcare variables , @a, and @b are variables
declare @a as int
declare @b int

--set value or assign value
set @a =11
set @b =55

--do calculation 
select @a+@b 

-- if condition  : decision making statement
declare @num int  
set @num = 124

if @num %2 = 0 
begin
		select 'even number'
end
else 
begin
		select 'odd number'
end


-- loop  : is iterator 
declare @i int 

set @i =1  -- start from 1
while @i<=50  --conditioni 
begin
	print @I 
	set @i =@i+1  -- incrementer
end

-- print in reverse 
declare @i int 

set @i =100  -- start from 1
while @i>0  --conditioni 
begin
	print @I 
	set @i =@i-1  -- decremneter
end

--- insert 100 rows in a table
select * from test 
declare @i int 

set @i =100  -- start from 1
while @i>0  --conditioni 
begin
	insert into test (name,email) 
	values('aa','bb@gamil.com')
	set @i =@i-1  -- decremneter
end

----
declare @m as int
set @m =1 
while @m<=5   
begin

	insert into test (name,email)
	values('bb'+convert(varchar,@m),'bb'+convert(varchar,@m)+'@gmail.com')
	set @m =@m+01
	
end


select * from test




select 'a'+ convert(varchar,1)




