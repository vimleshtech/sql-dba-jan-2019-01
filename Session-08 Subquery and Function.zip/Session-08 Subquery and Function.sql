/*
DDL
	create,alter,drop, truncate 
DML
	insert, updae, delete
DQL
	select
where 
operator
order by
group by
having 
aggregiate function 
suquery 

keywords
	top
	distinct
	select into
union 
data type 
constraints
join 
function : datefunction 
index
view 

case when 
wildcard
string function 
*/

use hrms 
--case when : is conditional statement
select * from employee


select eid,fname, 
case when gender='male'
   then 
		'm'
	else 
		'f'
end as gender
 from employee

 --wildcard : pattern match
 -- %   : any char any length
 -- _   : any char fix length

 select * from employee 

 --name start with a
 select * from employee where fname like 'a%'
 --name ending with a
 select * from employee where fname like '%a'

 --contains a
 select * from employee where fname like '%a%'

 --
 select * from employee where fname like ' j____' --any three char after a

 --
 select * from employee where emailid like 'r%@gmail.___'

--string function : 
-- upper(), lower(), len(), replace(), ltrim(), rtrim() , left(), right(), charindex()

select 
fname, lname,
upper(fname) ,
lower(fname) ,
len(fname),
replace(fname,'a','xy'),
ltrim(fname),
rtrim(fname),
left(fname,3),
right(fname,2),
CHARINDEX('a',fname) --return location or position of a
from employee 

create table idx_emp
(
id int primary key,
f_name varchar(50) not null,
lname varchar(50) null,
email varchar(40) unique,
gender char(1) check (gender in ('m','f')),
country varchar(50) check (country in ('India','US','AUS')),
status_id int default 1,
date datetime default getdate()
)

select * from idx_emp

insert into idx_emp(id,f_name)
values (2,'rehana');
insert into idx_emp(id,f_name,lname,email,gender,country,status_id) 
values(5,'mamta','sharma','mamta@gmail.com','f','India',2);

insert into idx_emp(id,f_name,email,gender,country,status_id)
values(6,'tulika','tul1@gmail.com','f','us',4);

insert into idx_emp(id,f_name,email,gender,country,status_id)
values(7,'jagriti','jagriti1@gmail.com','f','Aus',3);

select * from idx_emp

insert into idx_emp(id,f_name,email,gender,country,status_id)
values(1,'guru','guru1@gmail.com','m','Aus',9);

insert into idx_emp(id,f_name,email,gender,country,status_id)
values(1,'sharma ','guru1@gmail.com','m','India',8);

select f_name,lname,
upper (f_name),
lower(f_name),
len(f_name),
replace(f_name,'u','aa'),
ltrim(f_name),
rtrim(f_name),
left(f_name,2),
right(f_name,3)

from idx_emp


