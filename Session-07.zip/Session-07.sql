/*
INDEX  : is technique to store data in sorted order 
	   : index is important concept in database which enhance the reterival preformance of data 
	   : there are following types of index 
		i. cluster index		
						- is physically sorted   (dictionary)
						- primary key default cluster index 
						- only one cluster index can be created on a single table 		
		ii. non-cluster index 
						- virtual sorted		(text book)
						- 999 cluster index can be created on a single table
								

		
VIEW : is virtual table which store table structue and schema but not data 
	 : is can be use as wrapper over the table
	 : view can be use as a physical table with select statement 
 
*/

create table  orders
(
oid int,
cname varchar(100),
pname varchar(100),
qty int,
price int
)


insert into orders 
values(1,'ninit','dove',10,40)

insert into orders 
values(10,'ninit','dove',10,40)


insert into orders 
values(3,'ninit','dove',10,40)


insert into orders 
values(5,'ninit','dove',10,40)

select * from orders 


--create table with clsuter index/primary key
create table  orders_2
(
oid int primary key,
cname varchar(100),
pname varchar(100),
qty int,
price int
)


insert into orders_2 
values(1,'ninit','dove',10,40)

insert into orders_2 
values(10,'ninit','dove',10,40)


insert into orders_2 
values(3,'ninit','dove',10,40)


insert into orders_2 
values(5,'ninit','dove',10,40)


select * from orders_2 


-- show table strucrture and other constrains 
sp_help orders

sp_help orders_2 


-- create non-cluster index
create index x_name on orders(cname)
create index x_pname on orders(pname)


sp_help orders 



select * from orders



create view filter_rows
as
	select * from orders where oid > 3





create view view2
as
	select cname,pname,price from orders 




select * from filter_rows

select * from view2

